$(function () {

    //START OF CODE
    //the below line is an object(or the database)
    //First thing to define is the DATA of the application (Objects, properties) and its BEHAVIOUR (methods), which are methods that change the data based on a set of inputs

    const africaQuiz = {
        //below are properties
        totalScore: 10,
        currentQuestionIndex: 0,
        currentSelectedAnswer: undefined,
        questions: [
            {
                prompt: 'Africa is the _ largest continent',
                answers: {
                // property: 'value' - together they are a pair. Property value pairs are separated by commas
                    a: '1st',
                    b: '2nd',
                    c: '3rd',
                    d: '4th'
                }, 
                correctAnswerId: 'b'
            },   
            {
                prompt: 'Kenya is located in which part of Africa?',
                answers: {
                    a: 'East',
                    b: 'South',
                    c: 'West',
                    d: 'North'
                }, 
                correctAnswerId: 'a'
            },
            {
                prompt: 'Which African country is completely surrounded by only one other state?',
                answers: {
                    a: 'Ghana',
                    b: 'Rwanda',
                    c: 'Swaziland',
                    d: 'Lesotho'
                },
                correctAnswerId: 'd'
            }, 
            {                        
                prompt: 'Name this African state',
                image: './egypt-silhouette.jpg',
                answers: {
                    a: 'Angola',
                    b: 'Egypt',
                    c: 'Mali',
                    d: 'Eritrea'                            
                },
                correctAnswerId: 'b'
            },
            {
                prompt: 'Name this one too',
                image: './eritrea-silhouette.jpg',
                answers: { 
                    a: 'Angola',
                    b: 'Egypt',
                    c: 'Mali',
                    d: 'Eritrea'                              
                },
                correctAnswerId: 'd'
            },
            {
                prompt: 'Mozambique was a colony of which country?',
                answers: {
                    a: 'Portugal',
                    b: 'Great Britain',
                    c: 'Austro-Hungarian Empire',
                    d: 'France'
                },
                correctAnswerId: 'a'
            },
            {
                prompt: 'Which of the following countries is an archipelago?',
                answers: {
                    a: 'Central African Republic',
                    b: 'Malawi',
                    c: 'Seychelles',
                    d: 'Madagascar'
                },
                correctAnswerId: 'c'
            },
            {
                prompt: 'What is the capital of South Africa?',
                answers: {
                    a: 'Cape Town',
                    b: 'Pretoria',
                    c: 'Durban',
                    d: 'Johannesburg'
                },
                correctAnswerId: 'b'
            },
            {
                prompt: 'How many countries are there in Africa?',
                answers: {
                    a: '54',
                    b: '64',
                    c: '31',
                    d: '47'
                },
                correctAnswerId: 'a'
            }    
        ],
        //the below line is a METHOD. The parameter here (answerId) is what the client will be clicking on
        answerQuestion: function (answerId) {
            const currentQuestion = africaQuiz.questions[africaQuiz.currentQuestionIndex]
            //    when the question is answered, the next question appears and the current question disappears
                if (currentQuestion.correctAnswerId !== answerId) {
                    africaQuiz.totalScore--
                } 
                africaQuiz.currentQuestionIndex++
                return (currentQuestion.correctAnswerId === answerId)  
        }, 
        getCurrentQuestion: function () {
            return africaQuiz.questions[africaQuiz.currentQuestionIndex] 
        },

        isQuizOver: function () {
            return africaQuiz.currentQuestionIndex === africaQuiz.questions.length
        },
        resetQuiz: function () {
            africaQuiz.currentQuestionIndex = 0
            africaQuiz.totalScore = 10
        }
    }

    //The second thing we define is our EVENT LISTENERS, which mutate our data using the methods which are defined on our data. They are also going to potentially call "render functions" which will update the page
    const handleBeginQuiz = (event) => {
        $('#quizLanding').fadeOut(1000, function() {
            $('#quizLanding').css('visibility', 'hidden')
            $('#quizMain').css('visibility', 'visible')
            renderQuiz()
            renderScore()
            $('#quizMain').fadeTo(1000, 1)
            //pseudocode
            //set quizLanding to hidden
            //render quizMain
            //set #fade to visible
        })
    }
    
    const handleOptionSelection = (event) => {
            const eventTarget = event.target //get the raw DOM node that created the 'click' event
            const jQueryNodeTarget = $(eventTarget)
            const jQueryNodeMetaData = jQueryNodeTarget.data()
            const optionLetter = jQueryNodeMetaData.optionLetter
            console.log(optionLetter)
            africaQuiz.currentSelectedAnswer = optionLetter
            console.log(africaQuiz)
        }
    const handleSubmit = () => {
        if (!africaQuiz.currentSelectedAnswer) {return}
        $('#fade').fadeOut(1000, function() {//fade out
            console.log(africaQuiz.answerQuestion(africaQuiz.currentSelectedAnswer))//THEN answer question
            renderQuiz()
            renderScore()
            $('#fade').fadeIn(1000)//AFTER rendering, it then fades in
        })
    }

    //The below code renders 'Africa Quiz' JavaScript on the browser

    //The third thing we define is functions which re-render the DOM, or make it appear on the screen, based on the state of our data
    const renderQuiz = () => {

        //the below if statement is called an early return
        if (africaQuiz.isQuizOver() === true) {
            $('#questionPrompt').empty()
            $('#options').empty()
            return 
        }
        const currentQuestionToRender = africaQuiz.getCurrentQuestion()
        const questionPrompt = currentQuestionToRender.prompt
        const questionOptions = currentQuestionToRender.answers

        //Overall result of the below scope is to take each option in the questionOptions object and each loop will convert that option into a jQuery/DOM node, and add that node to a list
        let listOptionsToRender = []
        for (let option in questionOptions) {
            const listSingleOptionToRender = $(`<li>${questionOptions[option]}</li>`)//How it looks on the page
            const listOptionRadio = $(`<input type ="radio" name="option-${africaQuiz.answers}">`)
            listSingleOptionToRender.append(listOptionRadio)
            //What the rendered element represents in terms of data
            //add metadata and event listener
            listOptionRadio.data('optionLetter', option)
            //we have to bind this to a render method, see below
            //the event target is the DOM node that is creating the event. In the case above, clicking on the option will be the DOM node that is represented
            listOptionRadio.on('click', handleOptionSelection)
            
            listOptionsToRender.push(listSingleOptionToRender)
        }
        $('#questionPrompt').empty().append(currentQuestionToRender.prompt)
        $('#options').empty().append(listOptionsToRender)

        const currentQuestionImage = africaQuiz.getCurrentQuestion()
        const currentImageURL = currentQuestionImage.image
        
        //The below line makes the image render as HTML on the page
        $('#questionImage').empty()
        if (currentImageURL !== undefined) {
            $('#questionImage').empty().append(`<img src='${currentImageURL}'/>`)
        }
    }

    const renderScore = () => {
        if (africaQuiz.isQuizOver() === true) {
            $('#totalScore').empty()
            // alert(`You got ${africaQuiz.totalScore}!`)
            if (africaQuiz.totalScore === 10) {
                alert(`You got ${africaQuiz.totalScore}! You saved all the zebras! But the lions are still hungry...try again to feed the lions?`)
            } else if (africaQuiz.totalScore > 7) {
                alert(`You got ${africaQuiz.totalScore}! David can film the herd of zebras. Most of them anyway. Try again!`)
            } else if (africaQuiz.totalScore > 4) {
                alert(`You got ${africaQuiz.totalScore}! The lions ate well, but at least the documentary can be made. Try again!`)
            } else {
                alert(`You got ${africaQuiz.totalScore}! Looks like David Attenborough needs to cancel his filming permit...try again!`)
            }
            africaQuiz.resetQuiz()
            renderScore()
            renderQuiz()
            return 
        }
        
        let zebraImageTags =  ''
        for (let i = 0; i < africaQuiz.totalScore; i++) {
            zebraImageTags+= `<img class="zebra" src="zebra.jpg">`
        }
        console.log(zebraImageTags)
        $('#totalScore').empty().append(zebraImageTags)
    }       
    
    renderScore()

    $('#beginQuiz').on('click', handleBeginQuiz)

    //the below binds selecting an option from the quiz to the Submit Question button so that the quiz can proceed to the next question
    $('#submit').on('click', handleSubmit)


    
    renderQuiz()  
})


